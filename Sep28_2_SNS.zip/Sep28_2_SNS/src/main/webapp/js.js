function signUpgo(){
	location.href = "SignupController";
}

function logout(){
	let really = confirm("리얼루다가 ?");
	if (really) {
		location.href = "LoginController";
	}
}

